# Dual Network Downloader
Downloads one file over Wi-Fi and mobile data at the same time.
Push this folder to GitHub -> Actions tab -> "Build APK" -> download artifact.
