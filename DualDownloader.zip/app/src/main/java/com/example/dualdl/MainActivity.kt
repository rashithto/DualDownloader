package com.example.dualdl

import android.content.ContentValues
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {

    private val downloader by lazy { DualDownloader(NetworkAcquirer(this)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    @Composable
    private fun Screen() {
        val p by downloader.progress.collectAsState()
        val scope = rememberCoroutineScope()
        var url by remember { mutableStateOf("") }
        var useCell by remember { mutableStateOf(true) }
        var running by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Idle") }
        var job by remember { mutableStateOf<Job?>(null) }

        Column(
            Modifier.fillMaxSize().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Dual Network Downloader", style = MaterialTheme.typography.headlineSmall)

            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                label = { Text("Direct file URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = useCell, onCheckedChange = { useCell = it })
                Spacer(Modifier.width(8.dp))
                Text("Also use mobile data")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !running && url.isNotBlank(),
                    onClick = {
                        running = true
                        status = "Downloading..."
                        val t0 = SystemClock.elapsedRealtime()
                        job = scope.launch {
                            try {
                                val clean = url.trim()
                                val name = clean.substringAfterLast('/').substringBefore('?')
                                    .ifBlank { "download.bin" }
                                val tmp = File(getExternalFilesDir(null), name)
                                downloader.download(clean, tmp, useCell)
                                withContext(Dispatchers.IO) {
                                    copyToDownloads(tmp, name)
                                    tmp.delete()
                                }
                                val secs = (SystemClock.elapsedRealtime() - t0) / 1000.0
                                val mb = downloader.progress.value.done / 1_000_000.0
                                status = "Done in %.1f s (avg %.1f MB/s). Saved in Downloads/%s"
                                    .format(secs, mb / secs, name)
                            } catch (e: CancellationException) {
                                status = "Cancelled"
                                throw e
                            } catch (e: Exception) {
                                status = "Failed: ${e.message}"
                            } finally {
                                running = false
                            }
                        }
                    },
                ) { Text("Start") }

                OutlinedButton(enabled = running, onClick = { job?.cancel() }) {
                    Text("Cancel")
                }
            }

            LinearProgressIndicator(
                progress = { if (p.total > 0) p.done.toFloat() / p.total else 0f },
                modifier = Modifier.fillMaxWidth(),
            )
            Text("%.1f / %.1f MB".format(p.done / 1_000_000.0, p.total / 1_000_000.0))
            p.perNetwork.forEach { (net, bytes) ->
                Text("$net: %.1f MB".format(bytes / 1_000_000.0))
            }
            Text(status)
        }
    }

    private fun copyToDownloads(src: File, name: String) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openOutputStream(uri)?.use { out ->
            src.inputStream().use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
    }
}
