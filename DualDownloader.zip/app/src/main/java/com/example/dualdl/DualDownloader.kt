package com.example.dualdl

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume

/* ---------- Step 1: get a handle on each network ---------- */

class NetLease(
    val network: Network,
    private val cm: ConnectivityManager,
    private val cb: ConnectivityManager.NetworkCallback,
) {
    fun release() = runCatching { cm.unregisterNetworkCallback(cb) }
}

class NetworkAcquirer(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)

    /** transport = NetworkCapabilities.TRANSPORT_WIFI or TRANSPORT_CELLULAR */
    suspend fun acquire(transport: Int, timeoutMs: Long = 8_000): NetLease? =
        withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<NetLease> { cont ->
                val request = NetworkRequest.Builder()
                    .addTransportType(transport)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                val cb = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        if (cont.isActive) cont.resume(NetLease(network, cm, this))
                    }
                }
                cm.requestNetwork(request, cb)
                cont.invokeOnCancellation { runCatching { cm.unregisterNetworkCallback(cb) } }
            }
        }
}

/* ---------- Step 2: downloader ---------- */

data class Progress(
    val done: Long = 0,
    val total: Long = 0,
    val perNetwork: Map<String, Long> = emptyMap(),
)

private class Lane(val name: String, val lease: NetLease) {
    val bytes = AtomicLong()
    val client: OkHttpClient = OkHttpClient.Builder()
        .socketFactory(lease.network.socketFactory)            // route sockets via this network
        .dns(Dns { host -> lease.network.getAllByName(host).toList() }) // resolve via this network too
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
}

private class Chunk(val start: Long, val end: Long) {
    @Volatile var attempts = 0
}

class DualDownloader(
    private val acquirer: NetworkAcquirer,
    private val chunkSize: Long = 4L * 1024 * 1024,
    private val connsPerNetwork: Int = 3,
    private val maxAttempts: Int = 5,
) {
    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress

    suspend fun download(url: String, dest: File, useCellular: Boolean = true) {
        _progress.value = Progress()
        val wifi = acquirer.acquire(NetworkCapabilities.TRANSPORT_WIFI)
        val cell = if (useCellular) acquirer.acquire(NetworkCapabilities.TRANSPORT_CELLULAR) else null
        val lanes = listOfNotNull(
            wifi?.let { Lane("wifi", it) },
            cell?.let { Lane("cellular", it) },
        )
        if (lanes.isEmpty()) throw IOException("No usable network")
        try {
            run(url, dest, lanes)
        } finally {
            lanes.forEach { it.lease.release() }
        }
    }

    private suspend fun run(url: String, dest: File, lanes: List<Lane>) = coroutineScope {
        val (total, ranged) = probe(url, lanes.first().client)
        dest.parentFile?.mkdirs()

        RandomAccessFile(dest, "rw").use { raf ->
            if (total > 0) raf.setLength(total)
            val ch = raf.channel
            val done = AtomicLong()

            val ticker = launch {
                while (true) {
                    publish(done, total, lanes)
                    delay(500)
                }
            }

            if (ranged && total > 0) parallel(url, ch, total, lanes, done)
            else single(url, ch, lanes.first(), done)

            ticker.cancel()
            publish(done, total, lanes)
        }
    }

    private fun publish(done: AtomicLong, total: Long, lanes: List<Lane>) {
        _progress.value = Progress(done.get(), total, lanes.associate { it.name to it.bytes.get() })
    }

    /** Ask for byte 0 only: a 206 + Content-Range tells us size and range support. */
    private suspend fun probe(url: String, client: OkHttpClient): Pair<Long, Boolean> =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url(url).header("Range", "bytes=0-0").build()
            client.newCall(req).execute().use { resp ->
                if (resp.code == 206) {
                    val total = resp.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1L
                    total to (total > 0)
                } else if (resp.isSuccessful) {
                    (resp.body?.contentLength() ?: -1L) to false
                } else throw IOException("HTTP ${resp.code}")
            }
        }

    private suspend fun parallel(
        url: String, ch: FileChannel, total: Long, lanes: List<Lane>, done: AtomicLong,
    ) {
        val count = ((total + chunkSize - 1) / chunkSize).toInt()
        val queue = Channel<Chunk>(Channel.UNLIMITED)
        repeat(count) { i ->
            val s = i * chunkSize
            queue.trySend(Chunk(s, minOf(s + chunkSize, total) - 1))
        }
        val remaining = AtomicInteger(count)

        coroutineScope {
            lanes.forEach { lane ->
                repeat(connsPerNetwork) {
                    launch { worker(url, lane, queue, remaining, ch, done) }
                }
            }
        }
        if (remaining.get() > 0) throw IOException("Download incomplete")
    }

    /** Each worker pulls the next chunk, so the faster network naturally does more. */
    private suspend fun worker(
        url: String, lane: Lane, queue: Channel<Chunk>,
        remaining: AtomicInteger, ch: FileChannel, done: AtomicLong,
    ) {
        var failures = 0
        for (c in queue) {
            try {
                fetch(url, lane, c, ch, done)
                failures = 0
                if (remaining.decrementAndGet() == 0) queue.close()
            } catch (e: IOException) {
                if (++c.attempts >= maxAttempts) throw e
                queue.trySend(c)                 // give the chunk back
                if (++failures >= 3) return      // this network looks dead; others take over
                delay(500L * failures)
            }
        }
    }

    private suspend fun fetch(
        url: String, lane: Lane, c: Chunk, ch: FileChannel, done: AtomicLong,
    ) = withContext(Dispatchers.IO) {
        val call = lane.client.newCall(
            Request.Builder().url(url).header("Range", "bytes=${c.start}-${c.end}").build()
        )
        val handle = coroutineContext[Job]!!.invokeOnCompletion { if (it != null) call.cancel() }
        var written = 0L
        try {
            call.execute().use { resp ->
                if (resp.code != 206) throw IOException("Range not honoured: ${resp.code}")
                val stream = resp.body!!.byteStream()
                val buf = ByteArray(64 * 1024)
                var pos = c.start
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    ch.write(ByteBuffer.wrap(buf, 0, n), pos)   // positional write: thread-safe
                    pos += n
                    written += n
                    done.addAndGet(n.toLong())
                    lane.bytes.addAndGet(n.toLong())
                }
                if (pos != c.end + 1) throw IOException("Short read")
            }
        } catch (e: IOException) {
            done.addAndGet(-written)             // roll back counters before retry
            lane.bytes.addAndGet(-written)
            throw e
        } finally {
            handle.dispose()
        }
    }

    /** Fallback when the server has no range support: one plain stream. */
    private suspend fun single(url: String, ch: FileChannel, lane: Lane, done: AtomicLong) =
        withContext(Dispatchers.IO) {
            val call = lane.client.newCall(Request.Builder().url(url).build())
            val handle = coroutineContext[Job]!!.invokeOnCompletion { if (it != null) call.cancel() }
            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    val stream = resp.body!!.byteStream()
                    val buf = ByteArray(64 * 1024)
                    var pos = 0L
                    while (true) {
                        val n = stream.read(buf)
                        if (n < 0) break
                        ch.write(ByteBuffer.wrap(buf, 0, n), pos)
                        pos += n
                        done.addAndGet(n.toLong())
                        lane.bytes.addAndGet(n.toLong())
                    }
                }
            } finally {
                handle.dispose()
            }
        }
}
